import sqlite3
from datetime import datetime, timedelta

DB_NAME = "productivity.db"

def init_db():
    """Инициализация базы данных (создание таблиц)"""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            date TEXT,
            mood INTEGER,
            study_hours REAL,
            sleep_hours REAL,
            comment TEXT,
            FOREIGN KEY (user_id) REFERENCES users (user_id)
        )
    ''')
    conn.commit()
    conn.close()

def add_user(user_id, username):
    """Добавление нового пользователя"""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('INSERT OR IGNORE INTO users (user_id, username) VALUES (?, ?)', (user_id, username))
    conn.commit()
    conn.close()

def save_record(user_id, mood, study_hours, sleep_hours, comment=None):
    """Сохранение ежедневной записи"""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    date_str = datetime.now().strftime("%Y-%m-%d")
    
    cursor.execute('SELECT id FROM records WHERE user_id = ? AND date = ?', (user_id, date_str))
    existing = cursor.fetchone()
    
    if existing:
        cursor.execute('''
            UPDATE records 
            SET mood = ?, study_hours = ?, sleep_hours = ?, comment = ?
            WHERE id = ?
        ''', (mood, study_hours, sleep_hours, comment, existing[0]))
    else:
        cursor.execute('''
            INSERT INTO records (user_id, date, mood, study_hours, sleep_hours, comment)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (user_id, date_str, mood, study_hours, sleep_hours, comment))
        
    conn.commit()
    conn.close()

def get_stats(user_id, days=7):
    """Получение статистики за последние N дней"""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    date_limit = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    
    cursor.execute('''
        SELECT date, mood, study_hours, sleep_hours FROM records 
        WHERE user_id = ? AND date >= ?
        ORDER BY date ASC
    ''', (user_id, date_limit))
    
    data = cursor.fetchall()
    conn.close()
    return data