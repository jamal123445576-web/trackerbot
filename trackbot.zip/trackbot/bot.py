import asyncio
import logging
from datetime import datetime
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder
from dotenv import load_dotenv
import os

from db_handler import init_db, add_user, save_record, get_stats

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")

logging.basicConfig(level=logging.INFO)

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

class SurveyStates(StatesGroup):
    mood = State()
    study = State()
    sleep = State()
    comment = State()

def get_main_keyboard():
    """Главное меню (ReplyKeyboard)"""
    builder = ReplyKeyboardBuilder()
    builder.button(text="📝 Записать день")
    builder.button(text="📊 Статистика")
    builder.button(text="ℹ️ Помощь")
    builder.adjust(2, 1)
    return builder.as_markup(resize_keyboard=True)

def get_mood_keyboard():
    """Клавиатура для оценки настроения (Inline)"""
    builder = InlineKeyboardBuilder()
    for i in range(1, 6):
        builder.button(text=str(i), callback_data=f"mood_{i}")
    builder.adjust(5)
    return builder.as_markup()

def get_hours_keyboard(prefix):
    """Клавиатура для выбора часов (Inline)"""
    builder = InlineKeyboardBuilder()
    for i in [4, 5, 6, 7, 8, 9, 10, 12]:
        builder.button(text=str(i), callback_data=f"{prefix}_{i}")
    builder.button(text="Другое", callback_data=f"{prefix}_other")
    builder.adjust(4, 4, 1)
    return builder.as_markup()

@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    add_user(message.from_user.id, message.from_user.username)
    await message.answer(
        f"Привет, {message.from_user.first_name}! \n\n"
        "Я твой личный трекер продуктивности и настроения. "
        "Каждый день я буду спрашивать о твоем состоянии, а затем проанализирую данные, "
        "чтобы найти скрытые закономерности.\n\n"
        "Используй меню ниже, чтобы начать!",
        reply_markup=get_main_keyboard()
    )

@dp.message(F.text == "ℹ️ Помощь")
async def cmd_help(message: types.Message):
    await message.answer(
        "📖 Как пользоваться ботом:\n\n"
        "1. Нажми '📝 Записать день', чтобы внести данные за сегодня.\n"
        "2. Бот спросит твое настроение, часы учебы/работы и часы сна.\n"
        "3. Нажми '📊 Статистика', чтобы увидеть анализ твоих данных.\n\n"
        "Доступные команды:\n"
        "/start - Запуск бота\n"
        "/stats - Показать статистику"
    )

@dp.message(Command("stats"))
@dp.message(F.text == "📊 Статистика")
async def show_stats(message: types.Message):
    data = get_stats(message.from_user.id, days=30)
    
    if not data:
        await message.answer("У тебя пока нет записей. Начни с кнопки '📝 Записать день'!")
        return

    total_days = len(data)
    avg_mood = sum(row[1] for row in data) / total_days
    avg_study = sum(row[2] for row in data) / total_days
    avg_sleep = sum(row[3] for row in data) / total_days
    
    high_sleep_mood = [row[1] for row in data if row[3] >= 7]
    low_sleep_mood = [row[1] for row in data if row[3] < 7]
    
    insight = "Недостаточно данных для анализа закономерностей."
    if high_sleep_mood and low_sleep_mood:
        avg_high = sum(high_sleep_mood) / len(high_sleep_mood)
        avg_low = sum(low_sleep_mood) / len(low_sleep_mood)
        if avg_high > avg_low:
            insight = "💡 Закономерность: Когда ты спишь 7+ часов, твое настроение в среднем выше!"
        else:
            insight = "💡 Закономерность: Сон пока не сильно влияет на твое настроение."

    stats_text = (
        f"📊 Статистика за последние 30 дней\n\n"
        f"📅 Записей: {total_days}\n"
        f"😊 Среднее настроение: {avg_mood:.1f} / 5\n"
        f"📚 Среднее время учебы: {avg_study:.1f} ч.\n"
        f"😴 Среднее время сна: {avg_sleep:.1f} ч.\n\n"
        f"{insight}"
    )
    
    await message.answer(stats_text)

@dp.message(F.text == "📝 Записать день")
async def start_survey(message: types.Message, state: FSMContext):
    await state.set_state(SurveyStates.mood)
    await message.answer(
        "Оцени свое настроение сегодня от 1 до 5, где 1 — ужасно, 5 — отлично:",
        reply_markup=get_mood_keyboard()
    )

@dp.callback_query(SurveyStates.mood, F.data.startswith("mood_"))
async def process_mood(callback: types.CallbackQuery, state: FSMContext):
    mood = int(callback.data.split("_")[1])
    await state.update_data(mood=mood)
    
    await callback.message.edit_text(f"Настроение: {mood}/5 ✅")
    await callback.message.answer(
        "Сколько часов ты потратил на полезную работу/учебу?",
        reply_markup=get_hours_keyboard("study")
    )
    await state.set_state(SurveyStates.study)
    await callback.answer()

@dp.callback_query(SurveyStates.study, F.data.startswith("study_"))
async def process_study(callback: types.CallbackQuery, state: FSMContext):
    value = callback.data.split("_")[1]
    
    if value == "other":
        await callback.message.edit_text("Введи количество часов учебы цифрой (например, 3.5):")
        await callback.answer()
        return
        
    await state.update_data(study=float(value))
    await callback.message.edit_text(f"Учеба: {value} ч. ✅")
    await callback.message.answer(
        "Сколько часов ты спал?",
        reply_markup=get_hours_keyboard("sleep")
    )
    await state.set_state(SurveyStates.sleep)
    await callback.answer()

@dp.message(SurveyStates.study)
async def process_study_text(message: types.Message, state: FSMContext):
    try:
        hours = float(message.text.replace(',', '.'))
        await state.update_data(study=hours)
        await message.answer(f"Учеба: {hours} ч. ✅")
        await message.answer(
            "Сколько часов ты спал?",
            reply_markup=get_hours_keyboard("sleep")
        )
        await state.set_state(SurveyStates.sleep)
    except ValueError:
        await message.answer("Пожалуйста, введи число (например, 3.5):")

@dp.callback_query(SurveyStates.sleep, F.data.startswith("sleep_"))
async def process_sleep(callback: types.CallbackQuery, state: FSMContext):
    value = callback.data.split("_")[1]
    
    if value == "other":
        await callback.message.edit_text("Введи количество часов сна цифрой (например, 7.5):")
        await callback.answer()
        return
        
    await state.update_data(sleep=float(value))
    await callback.message.edit_text(f"Сон: {value} ч. ✅")
    await callback.message.answer(
        "Хочешь добавить комментарий? (Напиши текст или нажми 'Пропустить')",
        reply_markup=InlineKeyboardBuilder().button(text="Пропустить", callback_data="skip_comment").as_markup()
    )
    await state.set_state(SurveyStates.comment)
    await callback.answer()

@dp.message(SurveyStates.sleep)
async def process_sleep_text(message: types.Message, state: FSMContext):
    try:
        hours = float(message.text.replace(',', '.'))
        await state.update_data(sleep=hours)
        await message.answer(f"Сон: {hours} ч. ✅")
        await message.answer(
            "Хочешь добавить комментарий? (Напиши текст или нажми 'Пропустить')",
            reply_markup=InlineKeyboardBuilder().button(text="Пропустить", callback_data="skip_comment").as_markup()
        )
        await state.set_state(SurveyStates.comment)
    except ValueError:
        await message.answer("Пожалуйста, введи число (например, 7.5):")

@dp.callback_query(SurveyStates.comment, F.data == "skip_comment")
async def skip_comment(callback: types.CallbackQuery, state: FSMContext):
    await save_and_finish(callback.message, state, comment=None)
    await callback.answer()

@dp.message(SurveyStates.comment)
async def process_comment(message: types.Message, state: FSMContext):
    await save_and_finish(message, state, comment=message.text)

async def save_and_finish(message: types.Message, state: FSMContext, comment: str = None):
    data = await state.get_data()
    save_record(
        user_id=message.chat.id,
        mood=data['mood'],
        study_hours=data['study'],
        sleep_hours=data['sleep'],
        comment=comment
    )
    await state.clear()
    
    await message.answer(
        "✅ Данные успешно сохранены!\n\n"
        "Возвращайся завтра, чтобы продолжить отслеживание. "
        "А сейчас можешь посмотреть статистику.",
        reply_markup=get_main_keyboard()
    )

async def main():
    init_db() 
    print("Бот запущен...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())